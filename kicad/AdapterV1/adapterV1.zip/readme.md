Basis was this project migrated to KiCad 9.0 and added grove connectors.
https://github.com/botanicfields/KiCad-Template-M5Stack/tree/main